/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package construccion_1_estiven_alvarez;

import java.util.ArrayList;
import java.util.List;

public class Club {
    private List<Partner> partners;

    public Club() {
        this.partners = new ArrayList<>();
    }

    public boolean addPartner(Partner partner) {
        if (partners.size() < 35 && !existsPartnerWithID(partner.getID())) {
            partners.add(partner);
            return true;
        }
        return false;
    }

    public boolean removePartner(String ID) {
        Partner partnerToRemove = getPartnerByID(ID);

        if (partnerToRemove != null && canRemovePartner(partnerToRemove)) {
            partners.remove(partnerToRemove);
            return true;
        }
        return false;
    }

    protected boolean existsPartnerWithID(String ID) {
        for (Partner partner : partners) {
            if (partner.getID().equals(ID)) {
                return true;
            }
        }
        return false;
    }

    protected Partner getPartnerByID(String ID) {
        for (Partner partner : partners) {
            if (partner.getID().equals(ID)) {
                return partner;
            }
        }
        return null;
    }

    protected boolean canRemovePartner(Partner partner) {
        return partner.getMembershipType().equals("Regular") && partner.getUnpaidBills().isEmpty() && partner.getAuthorizedPersons().size() <= 1;
    }
}
