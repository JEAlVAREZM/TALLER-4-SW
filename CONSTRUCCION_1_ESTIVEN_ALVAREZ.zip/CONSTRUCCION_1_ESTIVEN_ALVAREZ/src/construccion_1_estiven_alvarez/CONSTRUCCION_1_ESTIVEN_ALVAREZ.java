 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package construccion_1_estiven_alvarez;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class CONSTRUCCION_1_ESTIVEN_ALVAREZ {

    List<List<Partner>> partnerDatabase = new ArrayList<>();
    List<Partner> partnerList = new ArrayList<>();

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Club club = new Club();

        int option;
        do {
            showMenu();
            option = scanner.nextInt();
            scanner.nextLine(); // Consume the new line after the option

            switch (option) {
                case 1:
                    affiliatePartner(scanner, club);
                    break;
                case 2:
                    registerAuthorizedPerson(scanner, club);
                    break;
                case 3:
                    payBill(scanner, club);
                    break;
                case 4:
                    registerConsumption(scanner, club);
                    break;
                case 5:
                    increaseFunds(scanner, club);
                    break;
                case 6:
                    deletePartner(scanner, club);
                    break;
                case 0:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please choose a correct option.");
            }
        } while (option != 0);
    }

    private static void showMenu() {
        System.out.println("Menu:");
        System.out.println("1. Affiliate a partner to the club.");
        System.out.println("2. Register an authorized person by a partner.");
        System.out.println("3. Pay a bill.");
        System.out.println("4. Register consumption in a partner's account.");
        System.out.println("5. Increase funds in a partner's account.");
        System.out.println("6. Delete a partner.");
        System.out.println("0. Exit");
        System.out.print("Select an option: ");
    }

    private static void affiliatePartner(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID:");
        String ID = scanner.nextLine();

        if (club.existsPartnerWithID(ID)) {
            System.out.println("Error: A partner with that ID already exists.");
            return;
        }

        System.out.println("Enter the partner's name:");
        String name = scanner.nextLine();
        System.out.println("Enter the subscription type (VIP or Regular):");
        String subscriptionType = scanner.nextLine();

        Partner newPartner = new Partner(ID, name, subscriptionType);

        if (club.addPartner(newPartner)) {
            System.out.println("Partner affiliated successfully.");
        } else {
            System.out.println("Error: Couldn't affiliate the partner. Check the restrictions.");
        }
    }

    private static void registerAuthorizedPerson(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID:");
        String partnerID = scanner.nextLine();

        Partner partner = club.getPartnerByID(partnerID);

        if (partner != null) {
            if (partner.getAuthorizedPersons().size() >= 10) {
                System.out.println("Error: The partner already has the maximum number of authorized persons.");
                return;
            }

            System.out.println("Enter the name of the authorized person:");
            String authorizedPersonName = scanner.nextLine();
            System.out.println("Enter the ID of the authorized person:");
            String authorizedPersonID = scanner.nextLine();

            AllowPerson authorizedPerson = new AllowPerson(authorizedPersonName, authorizedPersonID);

            if (partner.addAuthorizedPerson(authorizedPerson)) {
                System.out.println("Authorized person registered successfully.");
            } else {
                System.out.println("Error: Couldn't register the authorized person. Check the restrictions.");
            }
        } else {
            System.out.println("Error: Partner with the provided ID not found.");
        }
    }

    private static void payBill(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID:");
        String partnerID = scanner.nextLine();

        Partner partner = club.getPartnerByID(partnerID);

        if (partner != null) {
            List<Bill> unpaidBills = partner.getUnpaidBills();

            if (!unpaidBills.isEmpty()) {
                System.out.println("Unpaid bills:");

                for (int i = 0; i < unpaidBills.size(); i++) {
                    Bill bill = unpaidBills.get(i);
                    System.out.println((i + 1) + ". Concept: " + bill.getConcept() + ", Amount: $" + bill.getAmount());
                }

                System.out.println("Enter the number of the bill you want to pay:");
                int billNumber = scanner.nextInt();
                scanner.nextLine(); // Consume the new line after the bill number

                if (billNumber > 0 && billNumber <= unpaidBills.size()) {
                    Bill billToPay = unpaidBills.get(billNumber - 1);

                    if (partner.payBill(billToPay)) {
                        System.out.println("Bill paid successfully.");
                    } else {
                        System.out.println("Error: There are not enough funds to pay the bill.");
                    }
                } else {
                    System.out.println("Error: Invalid bill number.");
                }
            } else {
                System.out.println("The partner has no unpaid bills.");
            }
        } else {
            System.out.println("Error: Partner with the provided ID not found.");
        }
    }

    private static void registerConsumption(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID:");
        String partnerID = scanner.nextLine();

        Partner partner = club.getPartnerByID(partnerID);

        if (partner != null) {
            System.out.println("Enter the consumption concept:");
            String concept = scanner.nextLine();
            System.out.println("Enter the consumption amount:");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // Consume the new line after the amount

            if (amount <= partner.getAvailableFunds()) {
                Bill newBill = new Bill(concept, amount);
                partner.getUnpaidBills().add(newBill);

                System.out.println("Consumption registered successfully. Bill generated.");
            } else {
                System.out.println("Error: There are not enough funds to make the consumption.");
            }
        } else {
            System.out.println("Error: Partner with the provided ID not found.");
        }
    }

    private static void increaseFunds(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID:");
        String partnerID = scanner.nextLine();

        Partner partner = club.getPartnerByID(partnerID);

        if (partner != null) {
            System.out.println("Enter the amount to increase:");
            double increaseAmount = scanner.nextDouble();
            scanner.nextLine(); // Consume the new line after the amount

            if (partner.getAvailableFunds() + increaseAmount <= getFundsLimit(partner.getMembershipType())) {
                partner.setAvailableFunds(partner.getAvailableFunds() + increaseAmount);
                System.out.println("Funds increased successfully. New balance: $" + partner.getAvailableFunds());
            } else {
                System.out.println("Error: The increase amount exceeds the allowed limit.");
            }
        } else {
            System.out.println("Error: Partner with the provided ID not found.");
        }
    }

    private static double getFundsLimit(String membershipType) {
        return membershipType.equals("VIP") ? 5000000 : 1000000;
    }

    private static void deletePartner(Scanner scanner, Club club) {
        System.out.println("Enter the partner's ID you want to delete:");
        String partnerID = scanner.nextLine();

        Partner partner = club.getPartnerByID(partnerID);

        if (partner != null) {
            if (partner.getMembershipType().equals("VIP")) {
                System.out.println("Error: VIP partners cannot be deleted.");
            } else if (!partner.getUnpaidBills().isEmpty()) {
                System.out.println("Error: Partners with unpaid bills cannot be deleted.");
            } else if (partner.getAuthorizedPersons().size() > 1) {
                System.out.println("Error: Partners with more than one authorized person cannot be deleted.");
            } else {
                club.removePartner(partnerID);
                System.out.println("Partner deleted successfully.");
            }
        } else {
            System.out.println("Error: Partner with the provided ID not found.");
        }
    }
}
  
        
    
    

