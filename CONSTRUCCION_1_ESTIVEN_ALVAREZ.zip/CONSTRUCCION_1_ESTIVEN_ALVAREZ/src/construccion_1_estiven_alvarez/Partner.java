/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package construccion_1_estiven_alvarez;
import java.util.ArrayList;
import java.util.List;

public class Partner {
    private String ID;
    private String name;
    private String membershipType;
    private double availableFunds;
    private List<AllowPerson> authorizedPersons;
    private List<Bill> unpaidBills;

    public Partner() {
    }

    public Partner(String ID, String name, String membershipType) {
        this.ID = ID;
        this.name = name;
        this.membershipType = membershipType;
        this.availableFunds = membershipType.equals("VIP") ? 100000 : 50000;
        this.authorizedPersons = new ArrayList<>();
        this.unpaidBills = new ArrayList<>();
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMembershipType(String membershipType) {
        this.membershipType = membershipType;
    }

    public void setAvailableFunds(double availableFunds) {
        this.availableFunds = availableFunds;
    }

    public void setAuthorizedPersons(List<AllowPerson> authorizedPersons) {
        this.authorizedPersons = authorizedPersons;
    }

    public void setUnpaidBills(List<Bill> unpaidBills) {
        this.unpaidBills = unpaidBills;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getMembershipType() {
        return membershipType;
    }

    public double getAvailableFunds() {
        return availableFunds;
    }

    public List<AllowPerson> getAuthorizedPersons() {
        return authorizedPersons;
    }

    public List<Bill> getUnpaidBills() {
        return unpaidBills;
    }

    public boolean addAuthorizedPerson(AllowPerson authorizedPerson) {
        if (authorizedPersons.size() < 10) {
            authorizedPersons.add(authorizedPerson);
            return true;
        }
        return false;
    }

    public boolean payBill(Bill bill) {
        if (availableFunds >= bill.getAmount()) {
            availableFunds -= bill.getAmount();
            unpaidBills.remove(bill);
            return true;
        }
        return false;
    }
}
