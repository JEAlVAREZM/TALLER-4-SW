/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package construccion_1_estiven_alvarez;

public class Bill {
    private String concept;
    private double amount;

    public Bill() {
    }

    public void setConcept(String concept) {
        this.concept = concept;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Bill(String concept, double amount) {
        this.concept = concept;
        this.amount = amount;
    }

    public String getConcept() {
        return concept;
    }

    public double getAmount() {
        return amount;
    }
}
